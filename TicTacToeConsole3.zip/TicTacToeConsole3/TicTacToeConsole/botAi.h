#ifndef BOTAI_H
#define BOTAI_H

bool forBot(char zuege[], int botMoves[3]);
void botMove(char zuege[], int botMoves[3]);

#endif