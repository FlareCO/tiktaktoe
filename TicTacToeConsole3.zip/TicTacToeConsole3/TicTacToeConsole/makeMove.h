#ifndef MAKEMOVE_H
#define MAKEMOVE_H

void makeMove(char zuege[], char currentPlayer);

#endif