#ifndef HASWON_H
#define HASWON_H

int hasWon(char zuege[]);

#endif