#ifndef CHANGEPLAYER_H
#define CHANGEPLAYER_H

char changePlayer(char currentPlayer);

#endif