#include <iostream>
#include <stdlib.h>

using namespace std;

bool forBot(char zuege[], int botMoves[3]);
void botMove(char zuege[], int botMoves[3]);

bool forBot(char zuege[], int botMoves[3]){

	if ((zuege[0] == '1' || zuege[0] == 'O') &&
		(zuege[1] == '2' || zuege[1] == 'O') &&
		(zuege[2] == '3' || zuege[2] == 'O'))
	{
	
		botMoves[0] = 1;
		botMoves[1] = 2;
		botMoves[2] = 3;
		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O';
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else if ((zuege[3] == '4' || zuege[3] == 'O') &&
		(zuege[4] == '5' || zuege[4] == 'O') &&
		(zuege[5] == '6' || zuege[5] == 'O'))
	{
		botMoves[0] = 3;
		botMoves[1] = 4;
		botMoves[2] = 5;

		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O';
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else if ((zuege[6] == '7' || zuege[6] == 'O') &&
		(zuege[7] == '8' || zuege[7] == 'O') &&
		(zuege[8] == '9' || zuege[8] == 'O'))
	{
		botMoves[0] = 6;
		botMoves[1] = 7;
		botMoves[2] = 8;
		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O';
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else if ((zuege[0] == '1' || zuege[0] == 'O') &&
		(zuege[3] == '4' || zuege[3] == 'O') &&
		(zuege[6] == '7' || zuege[6] == 'O'))
	{
		botMoves[0] = 0;
		botMoves[1] = 3;
		botMoves[2] = 6;
		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O'; 
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else if ((zuege[1] == '2' || zuege[1] == 'O') &&
		(zuege[4] == '5' || zuege[4] == 'O') &&
		(zuege[7] == '8' || zuege[7] == 'O'))
	{
		botMoves[0] = 1;
		botMoves[1] = 4;
		botMoves[2] = 7;
		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O';
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else if ((zuege[2] == '3' || zuege[2] == 'O') &&
		(zuege[5] == '6' || zuege[5] == 'O') &&
		(zuege[8] == '9' || zuege[8] == 'O'))
	{
		botMoves[0] = 2;
		botMoves[1] = 5;
		botMoves[2] = 8;
		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O';
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else if ((zuege[0] == '1' || zuege[0] == 'O') &&
		(zuege[4] == '5' || zuege[4] == 'O') &&
		(zuege[8] == '9' || zuege[8] == 'O'))
	{
		botMoves[0] = 0; 
		botMoves[1] = 4;
		botMoves[2] = 8;

		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O';
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else if ((zuege[2] == '3' || zuege[2] == 'O') &&
		(zuege[4] == '5' || zuege[4] == 'O') &&
		(zuege[6] == '7' || zuege[6] == 'O'))
	{
		botMoves[0] = 2;
		botMoves[1] = 4;
		botMoves[2] = 6;
		if (zuege[botMoves[0]] != 'O'){
			zuege[botMoves[0]] = 'O';
			return true;
		}
		if (zuege[botMoves[1]] != 'O'){
			zuege[botMoves[1]] = 'O';
			return true;
		}
		if (zuege[botMoves[2]] != 'O'){
			zuege[botMoves[2]] = 'O';
			return true;
		}
		return true;
	}
	else
	{
		bool isEmpty = false;
		int random;
		do{
			random = rand() % 8;
			if (zuege[random] == 'X' || zuege[random] == 'O'){
			}
			else{
				zuege[random] = 'O';
				isEmpty = true;
			}
		} while (isEmpty == false);
		return true;
	}

}

void botMove(char zuege[], int botMoves[3]){

	/*
	0 1 2
	3 4 5
	6 7 8
	*/

	if (zuege[4] == 'X' && zuege[0] != 'O' && zuege[0] != 'X'){
		zuege[0] = 'O';
	}
	else{
		if (zuege[0] == zuege[1] && zuege[0] == 'X' && zuege[2] != 'O')
		{
			zuege[2] = 'O';
		}
		else if (zuege[3] == zuege[4] && zuege[3] == 'X' && zuege[5] != 'O')
		{
			zuege[5] = 'O';
		}
		else if (zuege[6] == zuege[7] && zuege[6] == 'X' && zuege[8] != 'O')
		{
			zuege[8] = 'O';
		}
		else if (zuege[0] == zuege[3] && zuege[0] == 'X' && zuege[6] != 'O')
		{
			zuege[6] = 'O';
		}
		else if (zuege[1] == zuege[4] && zuege[1] == 'X' && zuege[7] != 'O')
		{
			zuege[7] = 'O';
		}
		else if (zuege[2] == zuege[5] && zuege[2] == 'X' && zuege[8] != 'O')
		{
			zuege[8] = 'O';
		}
		else if (zuege[0] == zuege[4] && zuege[0] == 'X' && zuege[8] != 'O')
		{
			zuege[8] = 'O';
		}
		else if (zuege[2] == zuege[4] && zuege[2] == 'X' && zuege[6] != 'O')
		{
			zuege[6] = 'O';
		}
		else if (zuege[1] == zuege[2] && zuege[1] == 'X' && zuege[0] != 'O')
		{
			zuege[0] = 'O';
		}
		else if (zuege[4] == zuege[5] && zuege[4] == 'X' && zuege[3] != 'O')
		{
			zuege[3] = 'O';
		}
		else if (zuege[7] == zuege[8] && zuege[7] == 'X' && zuege[6] != 'O')
		{
			zuege[6] = 'O';
		}
		else if (zuege[3] == zuege[6] && zuege[3] == 'X' && zuege[0] != 'O')
		{
			zuege[0] = 'O';
		}
		else if (zuege[4] == zuege[7] && zuege[4] == 'X' && zuege[1] != 'O')
		{
			zuege[1] = 'O';
		}
		else if (zuege[5] == zuege[8] && zuege[5] == 'X' && zuege[2] != 'O')
		{
			zuege[2] = 'O';
		}
		else if (zuege[4] == zuege[8] && zuege[4] == 'X' && zuege[0] != 'O')
		{
			zuege[0] = 'O';
		}
		else if (zuege[4] == zuege[6] && zuege[4] == 'X' && zuege[2] != 'O')
		{
			zuege[2] = 'O';
		}
		else if (zuege[1] == zuege[2] && zuege[1] == 'X' && zuege[0] != 'O')
		{
			zuege[0] = 'O';
		}
		else if (zuege[4] == zuege[5] && zuege[4] == 'X' && zuege[3] != 'O')
		{
			zuege[3] = 'O';
		}
		else if (zuege[7] == zuege[8] && zuege[7] == 'X' && zuege[6] != 'O')
		{
			zuege[6] = 'O';
		}
		else if (zuege[3] == zuege[6] && zuege[3] == 'X' && zuege[0] != 'O')
		{
			zuege[0] = 'O';
		}
		else if (zuege[4] == zuege[7] && zuege[4] == 'X' && zuege[1] != 'O')
		{
			zuege[1] = 'O';
		}
		else if (zuege[5] == zuege[8] && zuege[5] == 'X' && zuege[2] != 'O')
		{
			zuege[2] = 'O';
		}
		else if (zuege[4] == zuege[8] && zuege[4] == 'X' && zuege[0] != 'O')
		{
			zuege[0] = 'O';
		}
		else if (zuege[4] == zuege[6] && zuege[4] == 'X' && zuege[2] != 'O')
		{
			zuege[2] = 'O';
		}
		else if (zuege[0] == zuege[2] && zuege[0] == 'X' && zuege[1] != 'O')
		{
			zuege[1] = 'O';
		}
		else if (zuege[3] == zuege[5] && zuege[3] == 'X' && zuege[4] != 'O')
		{
			zuege[4] = 'O';
		}
		else if (zuege[6] == zuege[8] && zuege[6] == 'X' && zuege[7] != 'O')
		{
			zuege[7] = 'O';
		}
		else if (zuege[0] == zuege[6] && zuege[0] == 'X' && zuege[3] != 'O')
		{
			zuege[3] = 'O';
		}
		else if (zuege[1] == zuege[7] && zuege[1] == 'X' && zuege[4] != 'O')
		{
			zuege[4] = 'O';
		}
		else if (zuege[2] == zuege[8] && zuege[2] == 'X' && zuege[5] != 'O')
		{
			zuege[5] = 'O';
		}
		else if (zuege[0] == zuege[8] && zuege[0] == 'X' && zuege[4] != 'O')
		{
			zuege[4] = 'O';
		}
		else if (zuege[2] == zuege[6] && zuege[2] == 'X' && zuege[4] != 'O')
		{
			zuege[4] = 'O';
		}
		else
		{
			bool isEmpty = false;
			int random;
			do{
				random = rand() % 8;
				if (zuege[random] == 'X' || zuege[random] == 'O'){
				}
				else{
					zuege[random] = 'O';
					isEmpty = true;
				}
			} while (isEmpty == false);
		}
	}

}

