#ifndef SPIELFELDAUSGABE_H
#define SPIELFELDAUSGABE_H

void spielfeldAusgabe(char zuege[]);

#endif