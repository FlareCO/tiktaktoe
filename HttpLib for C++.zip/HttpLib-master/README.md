# HttpLib
This is a minimalistic and easy to use requesting library for c++

# Features

### Currently supported methods
- GET
- HEAD
- POST
- PUT
- PATCH

# How to use

first of all you must include dll in your project which you can do like this:
```cpp
#include "SupportHeader.h"
#pragma comment (lib, "HttpLib.lib")
```
for more info about usage you can look at my example
